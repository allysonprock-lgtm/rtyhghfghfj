# Base Finder 1.2 (Fabric, Minecraft Java 26.1.2, client-side)

Finds likely player bases from the chunks your client loads and tells you where they are:
**block coordinates + chunk**. One entry per base, never one per chest.

## What's new in 1.2
- **Keybind in Options > Controls > Key Binds > Base Finder** (Right Shift by default). Rebind it like any other key.
- **Much stronger detection.** Bases are scored from many signals, not just chests:
  chests, trapped chests, barrels, shulker boxes (strong); ender chests, hoppers, droppers, dispensers,
  crafters, furnaces, blast furnaces, smokers, brewing stands, enchanting tables, beacons, conduits, lecterns,
  jukeboxes, bookshelves, beds, banners, armor stands, item frames (weaker, but they add up).
  Tight clusters AND spread-out bases (second "wide" pass over a 3x3 chunk area) are found, and every chunk
  with signals is re-checked every 10 seconds so late-arriving neighbours/entities are not missed.
- **Skips trap bases:** nothing is reported if a live **end crystal** or a **respawn anchor** is within 48 blocks.
  It also skips villages (a bell nearby) unless the score is huge.
- **Coordinates:** chat, action bar, Discord and the menu all show X Y Z (and chunk). Discord also shows the
  Nether/Overworld equivalent.
- **Snow-themed menu:** falling snowflakes, snow on the ground, frosted panel, rounded pill buttons and switches.

## Build the jar (GitHub, no local setup)
1. Upload everything in this folder to your GitHub repo (keep the hidden `.github` folder).
2. **Actions** tab -> "Build mod" runs on every push.
3. Download the jar from **Releases -> Latest build** or the run's **Artifacts**.

## Install
Fabric Loader 0.19.2+, Fabric API 0.146.1+26.1.2 (or newer), Java 25. Put `basefinder-1.2.0.jar` in `mods/`.

## The menu
Open it with your keybind. Left card: switches for detection / chat alert / sound alert / skip griefed-looking /
skip end-crystal bases / skip respawn-anchor bases; sensitivity (Normal / High / Extreme); webhook paste + clear.
Right card: recent finds with coordinates. Buttons: **Test alert** (uses your current position) and **Save & close**.
Esc closes without saving.

## Sensitivity presets
| Preset | Strong blocks needed | Score needed | Cluster radius |
|---|---|---|---|
| Normal | 6 | 8 | 12 |
| High (default) | 4 | 5 | 16 |
| Extreme | 3 | 3.5 | 20 |

## Discord webhook
Channel -> Edit Channel -> Integrations -> Webhooks -> New Webhook -> Copy URL, then in the menu press
**Paste from clipboard** and **Save & close**. Press **Test alert** to check it.

## Custom alert sound
Put an uncompressed **.wav** at `config/basefinder/alert.wav` (or change `customSoundFile`).

## config.json highlights (config/basefinder/config.json)
| Option | Meaning |
|---|---|
| `minStrongStorage`, `minScore`, `clusterRadius` | Tight-cluster thresholds (set by the sensitivity preset) |
| `wideScan`, `wideMinStrong`, `wideMinScore` | Spread-out base pass |
| `blockWeights`, `entityWeights` | Weight per block/entity id. >= 1.0 is "strong". A key starting with `*` matches the end of an id. 0 disables |
| `excludeEndCrystals`, `excludeRespawnAnchors`, `exclusionRadius` | Trap-base filter |
| `suppressNearBell`, `bellRadius`, `bellBypassScore` | Village filter |
| `requireIntactCheck`, `minSupportedRatio`, `minAvgEnclosure` | "Looks un-griefed" check |
| `dedupeChunkRadius` | Ignore new finds this close to a saved one |
| `dimensions` | Dimensions to watch |
| `discordWebhookUrl`, `apiEndpointUrl`, `apiAuthHeader` | Outputs |
| `alertChat`, `alertSound`, `customSoundFile`, `soundVolume`, `alertCooldownSeconds` | In-game alert |

## Limits
- Only chunks inside your render distance are visible to the client. Travel to cover more.
- End crystals are entities, so they only count once the client has them loaded (server entity range).
  The mod remembers crystals it has seen.
- Generated structures (trial chambers, bastions...) can still look like bases. Raise the preset or `minScore`.
