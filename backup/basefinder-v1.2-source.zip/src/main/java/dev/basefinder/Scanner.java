package dev.basefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Watches chunks as the client loads them and collects "base signals": storage blocks, workstations, beds,
 * beacons, armor stands, item frames... Each signal has a weight. Clusters of signals that add up to enough
 * weight (and enough strong storage) are reported as a base, unless they sit next to a live end crystal,
 * a respawn anchor, or a village bell.
 */
final class Scanner {
    /** One piece of evidence for a base. */
    record Sig(BlockPos pos, double w, boolean entity) {
        boolean strong() {
            return w >= 1.0;
        }
    }

    private record Pending(String dim, int cx, int cz, long due) {}

    private static final int[][] NEIGHBOURS = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

    private final Deque<Pending> pending = new ArrayDeque<>();
    private final Deque<Long> reeval = new ArrayDeque<>();
    private String reevalDim = "";

    private final Map<String, Map<Long, List<Sig>>> blockSigs = new HashMap<>();
    private final Map<String, Map<Long, List<Sig>>> entitySigs = new HashMap<>();
    private final Map<String, Map<Long, List<BlockPos>>> anchors = new HashMap<>();
    private final Map<String, Map<Long, List<BlockPos>>> bells = new HashMap<>();
    private final Map<String, Set<Long>> crystals = new HashMap<>();

    private long tick;
    private long lastEntityScan = -1000;
    private boolean inWorld;

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    static String dimKey(ClientLevel level) {
        // ResourceKey#toString looks like "ResourceKey[minecraft:dimension / minecraft:overworld]"
        String s = level.dimension().toString();
        int i = s.lastIndexOf(" / ");
        int j = s.lastIndexOf(']');
        return (i >= 0 && j > i) ? s.substring(i + 3, j) : s;
    }

    static String serverKey(Minecraft mc) {
        return mc.getCurrentServer() != null ? mc.getCurrentServer().ip : "singleplayer";
    }

    private static <T> Map<Long, List<T>> sub(Map<String, Map<Long, List<T>>> m, String dim) {
        return m.computeIfAbsent(dim, k -> new HashMap<>());
    }

    // ------------------------------------------------------------------ events

    void onChunkLoad(ClientLevel level, LevelChunk chunk) {
        Config cfg = BaseFinderClient.config;
        if (cfg == null || !cfg.enabled) return;
        String dim = dimKey(level);
        if (!cfg.watchesDimension(dim)) return;
        int cx = chunk.getPos().getMinBlockX() >> 4;
        int cz = chunk.getPos().getMinBlockZ() >> 4;
        // Scan twice: once shortly after load, and again once neighbouring chunks and entities have arrived.
        pending.add(new Pending(dim, cx, cz, tick + 40));
        pending.add(new Pending(dim, cx, cz, tick + 160));
    }

    void onChunkUnload(ClientLevel level, LevelChunk chunk) {
        String dim = dimKey(level);
        long k = key(chunk.getPos().getMinBlockX() >> 4, chunk.getPos().getMinBlockZ() >> 4);
        forget(blockSigs, dim, k);
        forget(anchors, dim, k);
        forget(bells, dim, k);
    }

    private static void forget(Map<String, ? extends Map<Long, ?>> m, String dim, long k) {
        Map<Long, ?> inner = m.get(dim);
        if (inner != null) inner.remove(k);
    }

    void tick(Minecraft mc) {
        tick++;
        Config cfg = BaseFinderClient.config;

        if (mc.level == null) {
            if (inWorld) {
                inWorld = false;
                pending.clear();
                reeval.clear();
                blockSigs.clear();
                entitySigs.clear();
                anchors.clear();
                bells.clear();
                crystals.clear();
            }
            return;
        }
        ClientLevel level = mc.level;

        if (!inWorld) {
            inWorld = true;
            if (cfg.sendTestOnJoin) Alerts.show(mc, Alerts.testDetection(mc), true);
        }

        if (tick % 100 == 0 && cfg.changedOnDisk()) {
            BaseFinderClient.config = Config.load();
            cfg = BaseFinderClient.config;
            BaseFinderClient.LOG.info("[BaseFinder] Config reloaded");
        }

        // Keybind from Options > Controls. consumeClick() only fires while no screen is open.
        while (BaseFinderClient.openKey != null && BaseFinderClient.openKey.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new BaseFinderScreen(null));
        }

        if (!cfg.enabled) {
            pending.clear();
            reeval.clear();
            return;
        }

        String dim = dimKey(level);
        if (!cfg.watchesDimension(dim)) return;

        // Entities (end crystals, armor stands, item frames) come and go, so refresh them regularly.
        boolean dueScan = !pending.isEmpty() && pending.peek().due() <= tick && tick - lastEntityScan >= 10;
        if (dueScan || tick - lastEntityScan >= 40) {
            lastEntityScan = tick;
            try {
                scanEntities(mc, level, dim);
            } catch (Exception e) {
                BaseFinderClient.LOG.warn("[BaseFinder] Entity scan failed", e);
            }
        }

        // Every 10 seconds, re-check every chunk that has signals (late entities, late neighbours).
        if (tick % 200 == 0 && reeval.isEmpty()) {
            Map<Long, List<Sig>> bm = blockSigs.get(dim);
            if (bm != null) {
                reevalDim = dim;
                reeval.addAll(bm.keySet());
            }
        }

        int budget = 3;
        while (budget > 0 && !pending.isEmpty() && pending.peek().due() <= tick) {
            Pending p = pending.poll();
            if (!p.dim().equals(dim)) continue;
            budget--;
            try {
                scan(mc, level, dim, p.cx(), p.cz());
            } catch (Exception e) {
                BaseFinderClient.LOG.warn("[BaseFinder] Scan failed for chunk {}, {}", p.cx(), p.cz(), e);
            }
        }

        int evalBudget = 6;
        while (evalBudget > 0 && !reeval.isEmpty()) {
            Long k = reeval.poll();
            if (!reevalDim.equals(dim)) continue;
            evalBudget--;
            try {
                evaluate(mc, level, dim, (int) (k >> 32), (int) (long) k);
            } catch (Exception e) {
                BaseFinderClient.LOG.warn("[BaseFinder] Re-check failed", e);
            }
        }
    }

    // ------------------------------------------------------------------ scanning

    private void scanEntities(Minecraft mc, ClientLevel level, String dim) {
        Config cfg = BaseFinderClient.config;
        Map<Long, List<Sig>> em = new HashMap<>();
        Set<Long> crystalsNow = new HashSet<>();

        for (Entity e : level.entitiesForRendering()) {
            String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
            BlockPos bp = e.blockPosition();
            if ("minecraft:end_crystal".equals(id)) {
                crystalsNow.add(bp.asLong());
                continue;
            }
            double w = cfg.entityWeight(id);
            if (w > 0) {
                em.computeIfAbsent(key(bp.getX() >> 4, bp.getZ() >> 4), k -> new ArrayList<>())
                        .add(new Sig(bp, w, true));
            }
        }
        entitySigs.put(dim, em);

        // Remember crystals we have seen, but forget ones that are gone when we are close enough to know.
        Set<Long> known = crystals.computeIfAbsent(dim, k -> new HashSet<>());
        known.addAll(crystalsNow);
        if (mc.player != null) {
            BlockPos pp = mc.player.blockPosition();
            known.removeIf(l -> !crystalsNow.contains(l)
                    && Math.abs(BlockPos.getX(l) - pp.getX()) < 24
                    && Math.abs(BlockPos.getY(l) - pp.getY()) < 24
                    && Math.abs(BlockPos.getZ(l) - pp.getZ()) < 24);
        }
    }

    private void scan(Minecraft mc, ClientLevel level, String dim, int cx, int cz) {
        Config cfg = BaseFinderClient.config;
        LevelChunk chunk = level.getChunk(cx, cz);

        List<Sig> sigs = new ArrayList<>();
        List<BlockPos> bellList = new ArrayList<>();
        for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
            String id = BuiltInRegistries.BLOCK.getKey(be.getBlockState().getBlock()).toString();
            if ("minecraft:bell".equals(id)) {
                bellList.add(be.getBlockPos());
                continue;
            }
            double w = cfg.blockWeight(id);
            if (w > 0) sigs.add(new Sig(be.getBlockPos(), w, false));
        }

        if (cfg.excludeRespawnAnchors) {
            List<BlockPos> found = findRespawnAnchors(chunk, cx, cz);
            if (found.isEmpty()) sub(anchors, dim).remove(key(cx, cz));
            else sub(anchors, dim).put(key(cx, cz), found);
        }

        Map<Long, List<Sig>> bm = sub(blockSigs, dim);
        if (bm.size() > 30000) bm.clear(); // keep memory bounded on very long sessions
        if (bellList.isEmpty()) sub(bells, dim).remove(key(cx, cz));
        else sub(bells, dim).put(key(cx, cz), bellList);

        if (sigs.isEmpty()) {
            bm.remove(key(cx, cz));
            return;
        }
        bm.put(key(cx, cz), sigs);
        evaluate(mc, level, dim, cx, cz);
    }

    /** Respawn anchors are not block entities, so look through the chunk's block palettes for them. */
    private static List<BlockPos> findRespawnAnchors(LevelChunk chunk, int cx, int cz) {
        List<BlockPos> out = new ArrayList<>();
        LevelChunkSection[] sections = chunk.getSections();
        int minSection = chunk.getMinY() >> 4;
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection s = sections[i];
            if (s == null || s.hasOnlyAir()) continue;
            if (!s.maybeHas(state -> state.is(Blocks.RESPAWN_ANCHOR))) continue;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (s.getBlockState(x, y, z).is(Blocks.RESPAWN_ANCHOR)) {
                            out.add(new BlockPos((cx << 4) + x, ((minSection + i) << 4) + y, (cz << 4) + z));
                        }
                    }
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ evaluation

    private static double sum(List<Sig> l) {
        double t = 0;
        for (Sig s : l) t += s.w();
        return t;
    }

    private static int strongCount(List<Sig> l) {
        int n = 0;
        for (Sig s : l) if (s.strong()) n++;
        return n;
    }

    private void evaluate(Minecraft mc, ClientLevel level, String dim, int cx, int cz) {
        Config cfg = BaseFinderClient.config;
        Map<Long, List<Sig>> bm = blockSigs.get(dim);
        if (bm == null) return;
        List<Sig> center = bm.get(key(cx, cz));
        if (center == null || center.isEmpty()) return;
        Map<Long, List<Sig>> em = entitySigs.get(dim);

        // This chunk plus its 8 neighbours, so clusters crossing chunk borders are seen whole.
        List<Sig> pts = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                List<Sig> l = bm.get(key(cx + dx, cz + dz));
                if (l != null) pts.addAll(l);
                if (em != null) {
                    List<Sig> e = em.get(key(cx + dx, cz + dz));
                    if (e != null) pts.addAll(e);
                }
            }
        }
        if (strongCount(pts) < cfg.minStrongStorage) return;
        if (pts.size() > 1500) pts = pts.subList(0, 1500);

        // Pass 1: the densest tight cluster anchored on a signal in this chunk.
        int r = cfg.clusterRadius;
        List<Sig> best = List.of();
        double bestScore = 0;
        int anchorsChecked = 0;
        for (Sig a : center) {
            if (++anchorsChecked > 60) break;
            List<Sig> members = new ArrayList<>();
            for (Sig p : pts) {
                if (Math.abs(p.pos().getX() - a.pos().getX()) <= r && Math.abs(p.pos().getY() - a.pos().getY()) <= r
                        && Math.abs(p.pos().getZ() - a.pos().getZ()) <= r) {
                    members.add(p);
                }
            }
            double score = sum(members);
            if (score > bestScore) {
                bestScore = score;
                best = members;
            }
        }
        String kind = "cluster";
        boolean ok = strongCount(best) >= cfg.minStrongStorage && bestScore >= cfg.minScore;

        // Pass 2: spread-out bases. Add up everything in the 3x3 chunk area.
        if (!ok && cfg.wideScan) {
            double total = sum(pts);
            if (strongCount(pts) >= cfg.wideMinStrong && total >= cfg.wideMinScore) {
                best = pts;
                bestScore = total;
                kind = "spread";
                ok = true;
            }
        }
        if (!ok) return;

        // Middle of the base (average of the strong signals).
        long sx = 0, sy = 0, sz = 0;
        int n = 0;
        for (Sig s : best) {
            if (!s.strong()) continue;
            sx += s.pos().getX();
            sy += s.pos().getY();
            sz += s.pos().getZ();
            n++;
        }
        if (n == 0) return;
        int x = (int) Math.floorDiv(sx, (long) n);
        int y = (int) Math.floorDiv(sy, (long) n);
        int z = (int) Math.floorDiv(sz, (long) n);

        if (isExcluded(cfg, dim, x, y, z, bestScore)) return;

        // "Does it look griefed?" heuristic: storage should sit on floors and be enclosed by other blocks.
        int supported = 0;
        int enclosure = 0;
        int blocks = 0;
        for (Sig s : best) {
            if (s.entity() || !s.strong()) continue;
            blocks++;
            BlockPos p = s.pos();
            if (!level.getBlockState(p.below()).isAir()) supported++;
            for (int[] o : NEIGHBOURS) {
                if (!level.getBlockState(p.offset(o[0], o[1], o[2])).isAir()) enclosure++;
            }
        }
        double supportRatio = blocks == 0 ? 1.0 : supported / (double) blocks;
        double avgEnclosure = blocks == 0 ? 6.0 : enclosure / (double) blocks;
        if (cfg.requireIntactCheck && (supportRatio < cfg.minSupportedRatio || avgEnclosure < cfg.minAvgEnclosure)) {
            return;
        }

        int baseCx = x >> 4;
        int baseCz = z >> 4;
        String server = serverKey(mc);
        if (BaseFinderClient.store.isDuplicate(server, dim, baseCx, baseCz, cfg.dedupeChunkRadius)) return;

        double conf = 0.40 * Math.min(1.0, supportRatio) + 0.25 * Math.min(1.0, avgEnclosure / 4.0)
                + 0.35 * Math.min(1.0, bestScore / 15.0);

        DetectionStore.Detection d = new DetectionStore.Detection();
        d.server = server;
        d.dimension = dim;
        d.chunkX = baseCx;
        d.chunkZ = baseCz;
        d.x = x;
        d.y = y;
        d.z = z;
        d.storageCount = strongCount(best);
        d.score = Math.round(bestScore * 10.0) / 10.0;
        d.kind = kind;
        d.supportRatio = Math.round(supportRatio * 100.0) / 100.0;
        d.avgEnclosure = Math.round(avgEnclosure * 10.0) / 10.0;
        d.confidence = (int) Math.round(conf * 100.0);
        d.foundAt = Instant.now().toString();

        BaseFinderClient.store.add(d, cfg.saveLocally);
        BaseFinderClient.LOG.info("[BaseFinder] Possible base at {}, {}, {} (chunk {}, {}) in {} - {} storage, score {}",
                x, y, z, baseCx, baseCz, dim, d.storageCount, d.score);
        Alerts.show(mc, d, false);
    }

    /** True if a live end crystal or respawn anchor is near the base, or the base is probably a village. */
    private boolean isExcluded(Config cfg, String dim, int x, int y, int z, double score) {
        long r2 = (long) cfg.exclusionRadius * cfg.exclusionRadius;

        if (cfg.excludeEndCrystals) {
            Set<Long> cs = crystals.get(dim);
            if (cs != null) {
                for (long l : cs) {
                    long dx = BlockPos.getX(l) - x, dy = BlockPos.getY(l) - y, dz = BlockPos.getZ(l) - z;
                    if (dx * dx + dy * dy + dz * dz <= r2) return true;
                }
            }
        }
        if (cfg.excludeRespawnAnchors) {
            if (anyNear(anchors.get(dim), x, y, z, cfg.exclusionRadius)) return true;
        }
        if (cfg.suppressNearBell && score < cfg.bellBypassScore) {
            if (anyNear(bells.get(dim), x, y, z, cfg.bellRadius)) return true;
        }
        return false;
    }

    private static boolean anyNear(Map<Long, List<BlockPos>> map, int x, int y, int z, int radius) {
        if (map == null || map.isEmpty()) return false;
        long r2 = (long) radius * radius;
        int span = (radius >> 4) + 1;
        int cx = x >> 4, cz = z >> 4;
        for (int dx = -span; dx <= span; dx++) {
            for (int dz = -span; dz <= span; dz++) {
                List<BlockPos> l = map.get(key(cx + dx, cz + dz));
                if (l == null) continue;
                for (BlockPos p : l) {
                    long ddx = p.getX() - x, ddy = p.getY() - y, ddz = p.getZ() - z;
                    if (ddx * ddx + ddy * ddy + ddz * ddz <= r2) return true;
                }
            }
        }
        return false;
    }
}
