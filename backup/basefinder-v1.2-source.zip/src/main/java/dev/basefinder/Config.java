package dev.basefinder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Settings, stored in config/basefinder/config.json. Edit the file; changes are picked up while the game runs. */
public final class Config {
    public static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("basefinder");
    public static final Path FILE = DIR.resolve("config.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Internal: used to migrate older config files. */
    public int version = 0;

    public boolean enabled = true;

    /** 0 = Normal, 1 = High, 2 = Extreme. Chosen in the menu; it rewrites the detection numbers below. */
    public int sensitivity = 1;

    /** A cluster needs at least this many "strong" blocks (weight >= 1.0: chests, barrels, shulkers...). */
    public int minStrongStorage = 4;
    /** ...and this total weighted score (all signals inside the cluster added up). */
    public double minScore = 5.0;
    /** Signals within this many blocks (box radius) of each other form one cluster. */
    public int clusterRadius = 16;

    /** Second pass for spread-out bases: looks at the whole 3x3 chunk area instead of one tight cluster. */
    public boolean wideScan = true;
    public int wideMinStrong = 8;
    public double wideMinScore = 12.0;

    /** A new detection is ignored if one already exists within this many chunks (same server + dimension). */
    public int dedupeChunkRadius = 4;

    /** Heuristic "does this look un-griefed" check. */
    public boolean requireIntactCheck = true;
    public double minSupportedRatio = 0.5;
    public double minAvgEnclosure = 1.5;

    /** Skip bases that have a live end crystal / a respawn anchor within exclusionRadius blocks. */
    public boolean excludeEndCrystals = true;
    public boolean excludeRespawnAnchors = true;
    public int exclusionRadius = 48;

    /** Villages have beds, barrels and furnaces. Skip clusters near a bell unless the score is very high. */
    public boolean suppressNearBell = true;
    public int bellRadius = 48;
    public double bellBypassScore = 25.0;

    /**
     * Block id -> weight. Weight >= 1.0 counts as "strong". A key starting with * matches the end of an id
     * (e.g. "*_bed"). Set a weight to 0 to ignore a block.
     */
    public Map<String, Double> blockWeights = defaultBlockWeights();
    /** Entity id -> weight (entities are checked every couple of seconds). */
    public Map<String, Double> entityWeights = defaultEntityWeights();

    /** Dimensions to watch. */
    public List<String> dimensions = new ArrayList<>(List.of(
            "minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"));

    public boolean saveLocally = true;

    /** Discord webhook URL (leave empty to disable). */
    public String discordWebhookUrl = "";
    public String discordUsername = "Base Finder";
    /** Optional generic HTTP endpoint that receives a JSON POST (leave empty to disable). */
    public String apiEndpointUrl = "";
    /** Optional value sent as the Authorization header to apiEndpointUrl. */
    public String apiAuthHeader = "";
    public boolean includeServerAddress = true;

    /** Minimum seconds between in-game chat/sound alerts (webhooks are never throttled). */
    public int alertCooldownSeconds = 3;
    public boolean alertChat = true;
    public boolean alertSound = true;
    /** WAV file name inside config/basefinder/, or an absolute path. Falls back to a built-in sound if missing. */
    public String customSoundFile = "alert.wav";
    /** 0.0 - 1.0 */
    public float soundVolume = 1.0f;

    /** Set true once to fire a fake detection on world join, to test the webhook and sound. */
    public boolean sendTestOnJoin = false;

    private transient Map<String, Double> exactBlock = new HashMap<>();
    private transient List<Map.Entry<String, Double>> suffixBlock = new ArrayList<>();
    private transient Map<String, Double> blockCache = new HashMap<>();
    private transient Set<String> dimSet = new HashSet<>();
    private transient long loadedStamp;

    private static Map<String, Double> defaultBlockWeights() {
        Map<String, Double> m = new LinkedHashMap<>();
        m.put("minecraft:chest", 1.0);
        m.put("minecraft:trapped_chest", 1.0);
        m.put("minecraft:barrel", 1.0);
        m.put("minecraft:shulker_box", 1.0);
        m.put("*_shulker_box", 1.0);
        m.put("minecraft:ender_chest", 0.5);
        m.put("minecraft:hopper", 0.5);
        m.put("minecraft:dropper", 0.4);
        m.put("minecraft:dispenser", 0.4);
        m.put("minecraft:crafter", 0.4);
        m.put("minecraft:furnace", 0.4);
        m.put("minecraft:blast_furnace", 0.4);
        m.put("minecraft:smoker", 0.4);
        m.put("minecraft:brewing_stand", 0.5);
        m.put("minecraft:enchanting_table", 0.6);
        m.put("minecraft:beacon", 3.0);
        m.put("minecraft:conduit", 1.5);
        m.put("minecraft:lectern", 0.3);
        m.put("minecraft:jukebox", 0.3);
        m.put("minecraft:chiseled_bookshelf", 0.3);
        m.put("*_bed", 0.6);
        m.put("*_banner", 0.15);
        return m;
    }

    private static Map<String, Double> defaultEntityWeights() {
        Map<String, Double> m = new LinkedHashMap<>();
        m.put("minecraft:armor_stand", 0.4);
        m.put("minecraft:item_frame", 0.25);
        m.put("minecraft:glow_item_frame", 0.25);
        return m;
    }

    /** Weight of a block id (0 if it is not a signal). */
    public double blockWeight(String id) {
        Double cached = blockCache.get(id);
        if (cached != null) return cached;
        double w = 0.0;
        Double exact = exactBlock.get(id);
        if (exact != null) {
            w = exact;
        } else {
            for (Map.Entry<String, Double> e : suffixBlock) {
                if (id.endsWith(e.getKey())) {
                    w = e.getValue();
                    break;
                }
            }
        }
        blockCache.put(id, w);
        return w;
    }

    public double entityWeight(String id) {
        Double w = entityWeights.get(id);
        return w == null ? 0.0 : w;
    }

    public boolean watchesDimension(String dim) {
        return dimSet.contains(dim);
    }

    /** Applies one of the sensitivity presets (0 normal, 1 high, 2 extreme) to the detection numbers. */
    public void applyPreset(int level) {
        sensitivity = Math.max(0, Math.min(2, level));
        switch (sensitivity) {
            case 0 -> {
                minStrongStorage = 6; minScore = 8.0; clusterRadius = 12;
                wideMinStrong = 12; wideMinScore = 18.0; minSupportedRatio = 0.6; minAvgEnclosure = 2.0;
            }
            case 1 -> {
                minStrongStorage = 4; minScore = 5.0; clusterRadius = 16;
                wideMinStrong = 8; wideMinScore = 12.0; minSupportedRatio = 0.5; minAvgEnclosure = 1.5;
            }
            default -> {
                minStrongStorage = 3; minScore = 3.5; clusterRadius = 20;
                wideMinStrong = 6; wideMinScore = 8.0; minSupportedRatio = 0.4; minAvgEnclosure = 1.0;
            }
        }
    }

    private void rebuild() {
        if (blockWeights == null) blockWeights = defaultBlockWeights();
        if (entityWeights == null) entityWeights = defaultEntityWeights();
        exactBlock = new HashMap<>();
        suffixBlock = new ArrayList<>();
        blockCache = new HashMap<>();
        for (Map.Entry<String, Double> e : blockWeights.entrySet()) {
            if (e.getKey().startsWith("*")) {
                suffixBlock.add(Map.entry(e.getKey().substring(1), e.getValue()));
            } else {
                exactBlock.put(e.getKey(), e.getValue());
            }
        }
        dimSet = new HashSet<>(dimensions);
        minStrongStorage = Math.max(1, minStrongStorage);
        clusterRadius = Math.max(1, clusterRadius);
        dedupeChunkRadius = Math.max(0, dedupeChunkRadius);
        exclusionRadius = Math.max(1, exclusionRadius);
        soundVolume = Math.max(0f, Math.min(1f, soundVolume));
        alertCooldownSeconds = Math.max(0, alertCooldownSeconds);
        if (discordWebhookUrl == null) discordWebhookUrl = "";
    }

    public static Config load() {
        Config cfg = null;
        try {
            Files.createDirectories(DIR);
            if (Files.exists(FILE)) {
                cfg = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), Config.class);
            }
        } catch (Exception e) {
            BaseFinderClient.LOG.warn("[BaseFinder] Could not read config, using defaults", e);
        }
        if (cfg == null) cfg = new Config();
        if (cfg.version < 2) { // older config: move detection numbers to the new defaults
            cfg.applyPreset(1);
            cfg.version = 2;
        }
        cfg.rebuild();
        cfg.save(); // writes any newly added options back to the file
        return cfg;
    }

    /** Re-validates values changed in code (e.g. by the menu) and writes the file. */
    public void applyAndSave() {
        rebuild();
        save();
    }

    public void save() {
        try {
            Files.createDirectories(DIR);
            Files.writeString(FILE, GSON.toJson(this), StandardCharsets.UTF_8);
            loadedStamp = Files.getLastModifiedTime(FILE).toMillis();
        } catch (IOException e) {
            BaseFinderClient.LOG.warn("[BaseFinder] Could not save config", e);
        }
    }

    /** True if the file on disk changed since we last loaded/saved it. */
    public boolean changedOnDisk() {
        try {
            return Files.exists(FILE) && Files.getLastModifiedTime(FILE).toMillis() != loadedStamp;
        } catch (IOException e) {
            return false;
        }
    }
}
