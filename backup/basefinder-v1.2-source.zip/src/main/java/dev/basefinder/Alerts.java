package dev.basefinder;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.time.Instant;

/** Everything that happens when a base is found: in-game message, sound, webhook. */
final class Alerts {
    private static long lastLocalAlert;

    private Alerts() {}

    static DetectionStore.Detection testDetection(Minecraft mc) {
        DetectionStore.Detection t = new DetectionStore.Detection();
        t.server = Scanner.serverKey(mc);
        t.dimension = mc.level != null ? Scanner.dimKey(mc.level) : "minecraft:overworld";
        BlockPos p = mc.player != null ? mc.player.blockPosition() : BlockPos.ZERO;
        t.x = p.getX();
        t.y = p.getY();
        t.z = p.getZ();
        t.chunkX = p.getX() >> 4;
        t.chunkZ = p.getZ() >> 4;
        t.storageCount = 12;
        t.score = 14.5;
        t.kind = "cluster";
        t.confidence = 88;
        t.supportRatio = 1.0;
        t.avgEnclosure = 3.0;
        t.foundAt = Instant.now().toString();
        return t;
    }

    static String prettyDim(String dim) {
        String s = dim.replace("minecraft:", "").replace('_', ' ');
        if (s.startsWith("the ")) s = s.substring(4);
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    static void show(Minecraft mc, DetectionStore.Detection d, boolean test) {
        Config cfg = BaseFinderClient.config;

        long now = System.currentTimeMillis();
        boolean local = test || now - lastLocalAlert >= cfg.alertCooldownSeconds * 1000L;
        if (local) {
            lastLocalAlert = now;

            if (cfg.alertChat && mc.player != null) {
                Component head = Component.literal("\u258C ").withStyle(ChatFormatting.AQUA)
                        .append(Component.literal(test ? "TEST ALERT" : "BASE FOUND")
                                .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD))
                        .append(Component.literal("  " + prettyDim(d.dimension)).withStyle(ChatFormatting.GRAY));
                Component coords = Component.literal("\u258C ").withStyle(ChatFormatting.AQUA)
                        .append(Component.literal("XYZ ").withStyle(ChatFormatting.GRAY))
                        .append(Component.literal(d.x + ", " + d.y + ", " + d.z)
                                .withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD))
                        .append(Component.literal("   chunk " + d.chunkX + ", " + d.chunkZ)
                                .withStyle(ChatFormatting.GRAY));
                Component detail = Component.literal("\u258C ").withStyle(ChatFormatting.AQUA)
                        .append(Component.literal(d.storageCount + " storage \u00B7 score "
                                + String.format("%.1f", d.score) + " \u00B7 " + d.confidence + "% confidence")
                                .withStyle(ChatFormatting.DARK_GRAY));
                Component bar = Component.literal((test ? "Test alert" : "Base found") + ": "
                        + d.x + ", " + d.y + ", " + d.z).withStyle(ChatFormatting.AQUA);

                mc.player.displayClientMessage(head, false);
                mc.player.displayClientMessage(coords, false);
                mc.player.displayClientMessage(detail, false);
                mc.player.displayClientMessage(bar, true); // action bar
            }
            if (cfg.alertSound) SoundPlayer.play(mc, cfg);
        }

        Notifier.send(cfg, d, test);
    }
}
