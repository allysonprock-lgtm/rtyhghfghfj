package dev.basefinder;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseFinderClient implements ClientModInitializer {
    public static final String MOD_ID = "basefinder";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    public static volatile Config config;
    public static DetectionStore store;
    /** Shows up in Options > Controls > Key Binds under "Base Finder". */
    public static KeyMapping openKey;
    private static Scanner scanner;

    @Override
    public void onInitializeClient() {
        config = Config.load();
        store = DetectionStore.load();
        scanner = new Scanner();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.basefinder.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category));

        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> scanner.onChunkLoad(level, chunk));
        ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> scanner.onChunkUnload(level, chunk));
        ClientTickEvents.END_CLIENT_TICK.register(scanner::tick);

        LOG.info("[BaseFinder] Loaded. Config: {}", Config.FILE);
    }
}
