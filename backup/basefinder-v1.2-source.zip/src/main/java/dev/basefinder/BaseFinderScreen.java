package dev.basefinder;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Snow-themed menu: pale icy background, falling snowflakes, snow on the ground, a frosted panel and
 * rounded, pill-shaped controls. Everything is drawn by hand (no vanilla widgets), so it looks the same
 * at every GUI scale. Open it with the key in Options > Controls (Right Shift by default).
 */
public class BaseFinderScreen extends Screen {
    // Palette
    private static final int SKY_TOP = 0xFFB4D2EE;
    private static final int SKY_BOTTOM = 0xFFF4F9FF;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int SNOW_SHADE = 0xFFDCE8F5;
    private static final int PANEL = 0xEFFFFFFF;
    private static final int PANEL_BORDER = 0xFFC9DDF2;
    private static final int CARD = 0xFFF2F7FD;
    private static final int CARD_BORDER = 0xFFD5E5F6;
    private static final int INK = 0xFF22344D;
    private static final int MUTED = 0xFF6D8199;
    private static final int ACCENT = 0xFF3B82F6;
    private static final int ACCENT_DARK = 0xFF2F6FD0;
    private static final int OK = 0xFF2E9E5B;
    private static final int TRACK_OFF = 0xFFC3D2E3;

    private record Hit(int x, int y, int w, int h, Runnable action) {}

    private static final class Flake {
        float x, y, speed, sway, phase;
        int size;
    }

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Flake> flakes = new ArrayList<>();
    private final Random rnd = new Random();
    private long lastNanos;
    private float time;

    // Editable state (written to the config on "Save & close")
    private boolean enabled, chat, sound, intact, exCrystals, exAnchors;
    private int sensitivity;
    private String webhook = "";
    private String status = "";

    public BaseFinderScreen(Screen parent) {
        super(Component.literal("Base Finder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = BaseFinderClient.config;
        enabled = c.enabled;
        chat = c.alertChat;
        sound = c.alertSound;
        intact = c.requireIntactCheck;
        exCrystals = c.excludeEndCrystals;
        exAnchors = c.excludeRespawnAnchors;
        sensitivity = c.sensitivity;
        webhook = c.discordWebhookUrl;

        flakes.clear();
        for (int i = 0; i < 95; i++) {
            Flake f = new Flake();
            f.x = rnd.nextFloat() * this.width;
            f.y = rnd.nextFloat() * this.height;
            f.speed = 14 + rnd.nextFloat() * 34;
            f.sway = 4 + rnd.nextFloat() * 12;
            f.phase = rnd.nextFloat() * 6.28f;
            float r = rnd.nextFloat();
            f.size = r < 0.58f ? 1 : (r < 0.86f ? 2 : 3);
            flakes.add(f);
        }
    }

    private void commit() {
        Config c = BaseFinderClient.config;
        c.enabled = enabled;
        c.alertChat = chat;
        c.alertSound = sound;
        c.requireIntactCheck = intact;
        c.excludeEndCrystals = exCrystals;
        c.excludeRespawnAnchors = exAnchors;
        if (sensitivity != c.sensitivity) c.applyPreset(sensitivity);
        c.discordWebhookUrl = webhook == null ? "" : webhook.trim();
        c.applyAndSave();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (Hit h : hits) {
                if (event.x() >= h.x() && event.x() < h.x() + h.w() && event.y() >= h.y() && event.y() < h.y() + h.h()) {
                    h.action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    // ------------------------------------------------------------------ drawing helpers

    private static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Filled rounded rectangle (r = corner radius in px). */
    private static void rrect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - dy * dy)));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private static void rrectBordered(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(g, x, y, w, h, r, border);
        rrect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    private static void vgrad(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int c1, int c2) {
        int h = y2 - y1;
        for (int y = 0; y < h; y += 3) {
            g.fill(x1, y1 + y, x2, Math.min(y2, y1 + y + 3), lerp(c1, c2, h <= 1 ? 0f : (float) y / (h - 1)));
        }
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(this.font, s, x, y, color, false);
    }

    private void textCentered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        g.text(this.font, s, cx - this.font.width(s) / 2, y, color, false);
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Pill-shaped button. */
    private void button(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, int mx, int my,
                        boolean primary, Runnable action) {
        boolean hover = inside(mx, my, x, y, w, h);
        int r = Math.min(10, h / 2);
        rrect(g, x, y + 2, w, h, r, 0x22284A70); // soft shadow
        int fill = primary ? (hover ? 0xFF4F94FF : ACCENT) : (hover ? 0xFFE6F1FF : WHITE);
        int border = primary ? ACCENT_DARK : (hover ? 0xFF8DB9E8 : 0xFFBBD3EC);
        rrectBordered(g, x, y, w, h, r, fill, border);
        if (!primary) g.fill(x + r, y + 1, x + w - r, y + 2, 0x66FFFFFF); // top gloss
        textCentered(g, label, x + w / 2, y + (h - 8) / 2, primary ? WHITE : INK);
        hits.add(new Hit(x, y, w, h, action));
    }

    /** Row with a label and an iOS-style switch. */
    private void toggle(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean on, int mx, int my,
                        Runnable flip) {
        if (inside(mx, my, x - 4, y, w + 8, h)) rrect(g, x - 4, y, w + 8, h, 5, 0x1A3B82F6);
        text(g, label, x, y + (h - 8) / 2, INK);
        int tw = 26, th = 12;
        int tx = x + w - tw, ty = y + (h - th) / 2;
        rrect(g, tx, ty, tw, th, 6, on ? ACCENT : TRACK_OFF);
        rrect(g, on ? tx + tw - 11 : tx + 1, ty + 1, 10, 10, 5, WHITE);
        hits.add(new Hit(x - 4, y, w + 8, h, flip));
    }

    private static void flakeShape(GuiGraphicsExtractor g, int x, int y, int size, int color) {
        if (size <= 1) {
            g.fill(x, y, x + 1, y + 1, color);
        } else if (size == 2) {
            g.fill(x, y, x + 2, y + 2, color);
        } else { // small plus-shaped crystal
            g.fill(x - 1, y, x + 2, y + 1, color);
            g.fill(x, y - 1, x + 1, y + 2, color);
        }
    }

    private static void snowflakeIcon(GuiGraphicsExtractor g, int cx, int cy, int color) {
        g.fill(cx - 6, cy, cx + 7, cy + 1, color);
        g.fill(cx, cy - 6, cx + 1, cy + 7, color);
        for (int i = -4; i <= 4; i++) {
            g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
            g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, color);
        }
        g.fill(cx - 2, cy - 5, cx + 3, cy - 4, color);
        g.fill(cx - 2, cy + 5, cx + 3, cy + 6, color);
    }

    private String maskUrl(String url) {
        if (url == null || url.isBlank()) return "Not set";
        String t = url.trim();
        return "Set  \u2026" + (t.length() > 8 ? t.substring(t.length() - 8) : t);
    }

    private static String ago(String iso) {
        try {
            long s = Duration.between(Instant.parse(iso), Instant.now()).getSeconds();
            if (s < 60) return "just now";
            if (s < 3600) return (s / 60) + "m ago";
            if (s < 86400) return (s / 3600) + "h ago";
            return (s / 86400) + "d ago";
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ main render

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        hits.clear();

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0f : Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;
        time += dt;
        for (Flake f : flakes) {
            f.y += f.speed * dt;
            f.x += (float) Math.sin(time * 0.9f + f.phase) * f.sway * dt;
            if (f.y > this.height + 4) {
                f.y = -4;
                f.x = rnd.nextFloat() * this.width;
            }
        }

        // ---- sky, frosted edges
        vgrad(g, 0, 0, this.width, this.height, SKY_TOP, SKY_BOTTOM);
        for (int i = 0; i < 22; i++) {
            int a = (int) (80 * (1 - i / 22f));
            int c = (a << 24) | 0xFFFFFF;
            g.fill(i, 0, i + 1, this.height, c);
            g.fill(this.width - 1 - i, 0, this.width - i, this.height, c);
            g.fill(0, i, this.width, i + 1, c);
        }

        // ---- far flakes (behind everything)
        for (Flake f : flakes) {
            if (f.size < 3) flakeShape(g, (int) f.x, (int) f.y, f.size, f.size == 1 ? 0xCCFFFFFF : 0xF2FFFFFF);
        }

        // ---- snow on the ground (two drifts)
        for (int x = 0; x < this.width; x += 3) {
            int h1 = 16 + (int) (5 * Math.sin(x * 0.04 + 0.6) + 3 * Math.sin(x * 0.11 + 1.3));
            g.fill(x, this.height - h1, x + 3, this.height, SNOW_SHADE);
        }
        for (int x = 0; x < this.width; x += 3) {
            int h2 = 9 + (int) (4 * Math.sin(x * 0.05 + 2.1) + 2 * Math.sin(x * 0.13));
            g.fill(x, this.height - h2, x + 3, this.height, WHITE);
        }

        // ---- panel
        int pw = Math.min(this.width - 16, 540);
        int ph = Math.min(this.height - 10, 288);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2;

        for (int i = 8; i >= 1; i--) { // frosted glow around the panel
            rrect(g, px - i, py - i, pw + 2 * i, ph + 2 * i, 12 + i, ((6 + (8 - i) * 2) << 24) | 0xFFFFFF);
        }
        rrect(g, px + 2, py + 5, pw, ph, 12, 0x2A27486E);
        rrectBordered(g, px, py, pw, ph, 12, PANEL, PANEL_BORDER);

        // snow piled on top of the panel
        for (int x = px + 14; x < px + pw - 14; x += 9) {
            int bump = 3 + (int) (2.5 * Math.sin(x * 0.21) + 1.5 * Math.sin(x * 0.57 + 1));
            rrect(g, x, py - bump, 13, bump + 4, 4, WHITE);
        }

        // ---- header
        snowflakeIcon(g, px + 24, py + 17, ACCENT);
        g.text(this.font, Component.literal("BASE FINDER").withStyle(ChatFormatting.BOLD), px + 38, py + 13, INK, false);
        text(g, "snow edition", px + 38 + this.font.width("BASE FINDER") + 12, py + 13, MUTED);
        String saved = BaseFinderClient.store.size() + " saved";
        text(g, saved, px + pw - 16 - this.font.width(saved), py + 13, MUTED);
        g.fill(px + 14, py + 28, px + pw - 14, py + 29, CARD_BORDER);

        // ---- layout
        int lx = px + 14;
        int ly = py + 36;
        int leftW = (int) ((pw - 42) * 0.50);
        int cardH = ph - 36 - 48;
        int rx = lx + leftW + 14;
        int rw = pw - 28 - leftW - 14;

        rrectBordered(g, lx, ly, leftW, cardH, 9, CARD, CARD_BORDER);
        rrectBordered(g, rx, ly, rw, cardH, 9, CARD, CARD_BORDER);

        // ---- left card: settings
        int cx0 = lx + 12;
        int cw = leftW - 24;
        int rowH = Math.max(12, Math.min(17, (cardH - 112) / 6));
        int y = ly + 9;
        text(g, "SETTINGS", cx0, y, ACCENT);
        y += 14;
        toggle(g, cx0, y, cw, rowH, "Detection", enabled, mx, my, () -> enabled = !enabled);
        y += rowH;
        toggle(g, cx0, y, cw, rowH, "Chat alert", chat, mx, my, () -> chat = !chat);
        y += rowH;
        toggle(g, cx0, y, cw, rowH, "Sound alert", sound, mx, my, () -> sound = !sound);
        y += rowH;
        toggle(g, cx0, y, cw, rowH, "Skip griefed-looking", intact, mx, my, () -> intact = !intact);
        y += rowH;
        toggle(g, cx0, y, cw, rowH, "Skip end crystal bases", exCrystals, mx, my, () -> exCrystals = !exCrystals);
        y += rowH;
        toggle(g, cx0, y, cw, rowH, "Skip respawn anchor bases", exAnchors, mx, my, () -> exAnchors = !exAnchors);
        y += rowH + 6;

        // sensitivity: segmented pill
        text(g, "Sensitivity", cx0, y, MUTED);
        y += 11;
        String[] names = {"Normal", "High", "Extreme"};
        int segW = cw / 3;
        rrectBordered(g, cx0, y, segW * 3, 16, 8, WHITE, 0xFFBBD3EC);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            int sx = cx0 + i * segW;
            boolean sel = sensitivity == i;
            boolean hov = inside(mx, my, sx, y, segW, 16);
            if (sel) rrect(g, sx + 1, y + 1, segW - 2, 14, 7, ACCENT);
            else if (hov) rrect(g, sx + 1, y + 1, segW - 2, 14, 7, 0xFFE6F1FF);
            textCentered(g, names[i], sx + segW / 2, y + 4, sel ? WHITE : INK);
            hits.add(new Hit(sx, y, segW, 16, () -> sensitivity = idx));
        }
        y += 22;

        // webhook
        text(g, "Discord webhook", cx0, y, MUTED);
        String shown = maskUrl(webhook);
        text(g, shown, cx0 + cw - this.font.width(shown), y, webhook == null || webhook.isBlank() ? MUTED : OK);
        y += 12;
        int half = (cw - 6) / 2;
        button(g, cx0, y, half, 16, "Paste from clipboard", mx, my, false, () -> {
            long win = GLFW.glfwGetCurrentContext();
            String clip = win == 0L ? null : GLFW.glfwGetClipboardString(win);
            if (clip != null && clip.trim().startsWith("https://")) {
                webhook = clip.trim();
                status = "Webhook pasted - press Save & close";
            } else {
                status = "Clipboard has no https:// link";
            }
        });
        button(g, cx0 + half + 6, y, half, 16, "Clear", mx, my, false, () -> {
            webhook = "";
            status = "Webhook cleared - press Save & close";
        });

        // ---- right card: recent finds
        int rx0 = rx + 12;
        text(g, "RECENT FINDS", rx0, ly + 9, ACCENT);
        int entryH = 34;
        int maxRows = Math.max(1, (cardH - 28) / entryH);
        List<DetectionStore.Detection> recent = BaseFinderClient.store.recent(maxRows);
        if (recent.isEmpty()) {
            text(g, "Nothing found yet.", rx0, ly + 30, MUTED);
            text(g, "Explore to load chunks.", rx0, ly + 42, MUTED);
        }
        int ey = ly + 24;
        for (DetectionStore.Detection d : recent) {
            int bar = d.confidence >= 75 ? OK : 0xFF5DADE2;
            rrect(g, rx0, ey + 1, 3, 26, 1, bar);
            String coords = (d.x == 0 && d.y == 0 && d.z == 0)
                    ? "Chunk " + d.chunkX + ", " + d.chunkZ
                    : d.x + ", " + d.y + ", " + d.z;
            g.text(this.font, Component.literal(coords).withStyle(ChatFormatting.BOLD), rx0 + 8, ey, INK, false);
            text(g, "chunk " + d.chunkX + ", " + d.chunkZ + " \u00B7 " + Alerts.prettyDim(d.dimension), rx0 + 8, ey + 10, MUTED);
            text(g, d.storageCount + " storage \u00B7 " + d.confidence + "% \u00B7 " + ago(d.foundAt), rx0 + 8, ey + 20, MUTED);
            ey += entryH;
        }

        // ---- footer buttons
        int fy = py + ph - 36;
        button(g, lx, fy, 120, 22, "Test alert", mx, my, false, () -> {
            commit();
            Alerts.show(this.minecraft, Alerts.testDetection(this.minecraft), true);
            status = "Test alert sent";
        });
        button(g, px + pw - 14 - 140, fy, 140, 22, "Save & close", mx, my, true, () -> {
            commit();
            onClose();
        });
        if (!status.isEmpty()) textCentered(g, status, px + pw / 2, fy + 7, MUTED);

        // ---- near flakes (in front of the panel)
        for (Flake f : flakes) {
            if (f.size == 3) flakeShape(g, (int) f.x, (int) f.y, 3, 0xCC8FC3F2);
        }
    }
}
